FindYourPlace


Package per il progetto FindYourPlace per l'esame di Fondamenti di Intelligenza Artificiale
(Corso di Informatica - UniSA)


Autori:

Pietro Esposito - p.esposito62@studenti.unisa.it 

Alessandro Nacchia - a.nacchia9@studenti.unisa.it

Lorenzo Castellano - l.castellano4@studenti.unisa.it